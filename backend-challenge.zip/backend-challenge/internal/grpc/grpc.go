// Package grpc implements a set of utilities around gRPC + Protobuf to provide low-latency
// API-contract-driven development.
package grpc
