package app

import (
	"github.com/buffup/backend-challenge/config"
	sdkgrpc "github.com/buffup/backend-challenge/internal/grpc"
	"github.com/buffup/backend-challenge/internal/o11y"
	"github.com/buffup/backend-challenge/internal/support"

	"google.golang.org/grpc"
)

// Server is the app's GRPC server.
var Server *sdkgrpc.Server

// Config is the app's config.
var Config config.EnvConfig

// NewServer initialises the gRPC server.
func NewServer(config config.EnvConfig, logger *support.Logger, tracerProvider *o11y.TracerProvider, tracerProviderShutdownHandler, postRunCallback func() error, unaryServerInterceptors []grpc.UnaryServerInterceptor) (*sdkgrpc.Server, error) {
	return sdkgrpc.NewServer(
		&sdkgrpc.ServerConfig{
			Address: config.GRPCAddress,
			GracefulShutdownHandler: func() error {
				return nil
			},
			GRPCGatewayServer:             "platform",
			TracerProvider:                tracerProvider,
			TracerProviderShutdownHandler: tracerProviderShutdownHandler,
		},
		logger,
		postRunCallback,
		unaryServerInterceptors...,
	)
}
