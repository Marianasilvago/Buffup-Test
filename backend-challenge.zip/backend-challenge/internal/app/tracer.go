package app

import (
	"github.com/buffup/backend-challenge/config"
	"github.com/buffup/backend-challenge/internal/o11y"
)

// Tracer is the app's OpenTelemetry tracer.
var Tracer o11y.Tracer

// NewTracer initialises the OpenTelemetry tracer.
func NewTracer(config config.EnvConfig) (o11y.Tracer, *o11y.TracerProvider, func() error, error) {
	tracerProvider, traceProviderShutdownHandler, err := o11y.NewTracerProvider(
		&o11y.TracerProviderConfig{
			ServiceName:      config.ServiceName,
			CollectorAddress: config.TracerCollectorAddress,
		},
	)
	if err != nil {
		return o11y.Tracer{}, nil, nil, err
	}

	return o11y.NewTracer("app"), tracerProvider, traceProviderShutdownHandler, err
}
