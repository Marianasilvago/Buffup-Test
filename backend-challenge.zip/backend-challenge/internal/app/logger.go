package app

import (
	"github.com/buffup/backend-challenge/internal/support"
)

// Logger is the app's logger.
var Logger *support.Logger
