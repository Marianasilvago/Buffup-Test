package entities

import (
	"time"

	"github.com/google/uuid"
)

type Leaderboard struct {
	ID          uuid.UUID
	GameID      []uuid.UUID
	Description string
	CreatedAt   time.Time
}

type LeaderBoardResponse struct {
	EntityId    uuid.UUID
	TotalPoints int64
	Rank        int64
	Position    int64
}
