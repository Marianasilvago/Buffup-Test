package entities

import (
	"github.com/google/uuid"
)

type Point struct {
	EntityID uuid.UUID
	GameID   uuid.UUID
	Count    uint
}
