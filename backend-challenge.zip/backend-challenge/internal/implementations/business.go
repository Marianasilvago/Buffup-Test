package implementations

import (
	"context"
	"errors"

	"github.com/buffup/backend-challenge/api"
	"github.com/buffup/backend-challenge/internal/entities"
	"github.com/google/uuid"
)

//AwardPoints implements the business logic for awarding points
func (s *Server) AwardPoints(ctx context.Context, in *api.AwardPointsRequest) (*api.AwardPointsResponse, error) {
	if in.EntityUuid == "" || in.GameUuid == "" {
		return nil, errors.New("Bad request")
	}
	entityId, err := uuid.Parse(in.EntityUuid)
	if err != nil {
		return nil, err
	}
	gameId, err := uuid.Parse(in.GameUuid)
	if err != nil {
		return nil, err
	}
	refId, err := s.store.AwardPoints(ctx, entities.Point{
		EntityID: entityId,
		GameID:   gameId,
		Count:    uint(in.Points),
	})
	if err != nil {
		return nil, err
	}
	return &api.AwardPointsResponse{
		Uuid: refId.String(),
	}, nil
}

//CreateLeaderboard implements the business logic for creating a leaderboard for a game
func (s *Server) CreateLeaderboard(ctx context.Context, in *api.CreateLeaderboardRequest) (*api.CreateLeaderboardResponse, error) {
	if in.GameUuids == nil || len(in.GameUuids) < 1 {
		return nil, errors.New("Bad request")
	}

	gameUuids := make([]uuid.UUID, 0)
	for _, id := range in.GameUuids {
		gameId, err := uuid.Parse(id)
		if err != nil {
			return nil, err
		}
		gameUuids = append(gameUuids, gameId)
	}

	refId, err := s.store.CreateLeaderboard(ctx, gameUuids)
	if err != nil {
		return nil, err
	}

	return &api.CreateLeaderboardResponse{
		LeaderboardUuid: refId.String(),
	}, nil
}

//GetLeaderboard implements the business logic for fetching a leaderboard of a game
func (s *Server) GetLeaderboard(ctx context.Context, in *api.GetLeaderboardRequest) (*api.GetLeaderboardResponse, error) {
	if in.LeaderboardUuid == "" {
		return nil, errors.New("Bad request")
	}
	leaderboardId, err := uuid.Parse(in.LeaderboardUuid)
	if err != nil {
		return nil, err
	}

	result, err := s.store.GetLeaderboard(ctx, leaderboardId)
	if err != nil {
		return nil, err
	}

	res := &api.GetLeaderboardResponse{
		Rows: make([]*api.GetLeaderboardResponse_LeaderboardRow, 0),
	}

	for _, row := range result {
		res.Rows = append(res.Rows, &api.GetLeaderboardResponse_LeaderboardRow{
			EntityUuid:  row.EntityId.String(),
			TotalPoints: row.TotalPoints,
			Rank:        row.Rank,
			Position:    row.Position,
		})
	}

	return res, nil
}
