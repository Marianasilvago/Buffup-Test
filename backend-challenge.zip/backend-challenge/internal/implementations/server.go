package implementations

import (
	"github.com/buffup/backend-challenge/api"
	"github.com/buffup/backend-challenge/internal/database"
)

type Server struct {
	api.UnimplementedPointServiceServer
	store database.Store
}

func NewServer(store database.Store) *Server {
	return &Server{
		store: store,
	}
}
