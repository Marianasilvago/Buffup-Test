package database

import (
	"context"

	"github.com/buffup/backend-challenge/internal/entities"
	"github.com/google/uuid"
)

//Store defines the database contracts
type Store interface {
	AwardPoints(ctx context.Context, point entities.Point) (uuid.UUID, error)
	CreateLeaderboard(ctx context.Context, gameIDs []uuid.UUID) (uuid.UUID, error)
	GetLeaderboard(ctx context.Context, leaderboardID uuid.UUID) ([]entities.LeaderBoardResponse, error)

	Migrate(ctx context.Context) error
	Seed(ctx context.Context) error

	Close() error
}
