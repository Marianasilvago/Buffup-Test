package mock

import (
	"context"

	"github.com/buffup/backend-challenge/internal/entities"
	"github.com/buffup/backend-challenge/internal/support"
	"github.com/google/uuid"
)

type Store struct {
	logger *support.Logger

	AwardPointsFn       func(ctx context.Context, point entities.Point) (uuid.UUID, error)
	CreateLeaderboardFn func(ctx context.Context, gameIDs []uuid.UUID) (uuid.UUID, error)
	GetLeaderboardFn    func(ctx context.Context, leaderboardID uuid.UUID) ([]entities.LeaderBoardResponse, error)

	MigrateFn func(ctx context.Context) error
	SeedFn    func(ctx context.Context) error
}

func NewStore(ctx context.Context, logger *support.Logger) *Store {
	return &Store{logger: logger}
}

func (s *Store) AwardPoints(ctx context.Context, point entities.Point) (uuid.UUID, error) {
	return s.AwardPointsFn(ctx, point)
}
func (s *Store) CreateLeaderboard(ctx context.Context, gameIDs []uuid.UUID) (uuid.UUID, error) {
	return s.CreateLeaderboardFn(ctx, gameIDs)
}
func (s *Store) GetLeaderboard(ctx context.Context, leaderboardID uuid.UUID) ([]entities.LeaderBoardResponse, error) {
	return s.GetLeaderboardFn(ctx, leaderboardID)
}
func (s *Store) Migrate(ctx context.Context) error {
	return s.MigrateFn(ctx)
}
func (s *Store) Seed(ctx context.Context) error {
	return s.SeedFn(ctx)
}
func (s *Store) Close() error {
	return nil
}
