package postgres

import (
	"context"
	"fmt"

	"github.com/buffup/backend-challenge/internal/support"
	"github.com/jackc/pgx/v4/pgxpool"
)

type Store struct {
	db     *pgxpool.Pool
	logger *support.Logger
	dsn    string
}

func NewStore(ctx context.Context, dsn string, logger *support.Logger) (*Store, error) {
	if db, err := connect(ctx, dsn); err != nil {
		return nil, err
	} else {
		return &Store{
			db:     db,
			dsn:    dsn,
			logger: logger,
		}, nil
	}
}

func (s *Store) Close() error {
	if s.db != nil {
		s.db.Close()
	}

	return nil
}

// Connect establishes a connection to the provided database dsn using the standard library driver
func connect(ctx context.Context, dsn string) (*pgxpool.Pool, error) {
	conn, err := pgxpool.Connect(context.Background(), dsn)
	if err != nil {
		return nil, fmt.Errorf("unable to connect to database: %w", err)
	}

	return conn, nil
}
