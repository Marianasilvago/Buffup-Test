package postgres

import (
	"context"
	"embed"
	"errors"
	"fmt"
	"net/http"
	"sort"
	"strings"

	"github.com/buffup/backend-challenge/migrations"
	"github.com/golang-migrate/migrate/v4"
	_ "github.com/golang-migrate/migrate/v4/database/postgres"
	"github.com/golang-migrate/migrate/v4/source/httpfs"
)

func (s *Store) Migrate(ctx context.Context) error {
	source, err := httpfs.New(http.FS(migrations.FS_Migrate), ".")
	if err != nil {
		return fmt.Errorf("failed to load migrations: %w", err)
	}

	m, err := migrate.NewWithSourceInstance("httpfs", source, s.dsn)
	if err != nil {
		return fmt.Errorf("failed to create migrate instance: %w", err)
	}

	return m.Up()
}

// Seed initialises the DB seeder with open connection.
func (s *Store) Seed(ctx context.Context) error {
	entries, err := migrations.FS_Seed.ReadDir("seed")
	if err != nil {
		return err
	}

	files := []string{}
	for _, entry := range entries {
		if !entry.IsDir() && strings.HasSuffix(entry.Name(), ".sql") && entry.Name() != "init.sql" {
			files = append(files, fmt.Sprintf("%s/%s", "seed", entry.Name()))
		}
	}

	if len(files) < 1 {
		return errors.New("no seed files found")
	}

	sort.Strings(files)

	return s.run(ctx, migrations.FS_Seed, files)
}

// Run executes the seeding.
func (s *Store) run(ctx context.Context, embedFS embed.FS, files []string) error {
	// db, err := sqlx.Open("postgres", s.dsn)
	// if err != nil {
	// 	return err
	// }

	// defer db.Close()

	for _, file := range files {
		b, err := embedFS.ReadFile(file)
		if err != nil {
			return err
		}

		if len(b) == 0 {
			continue
		}

		if _, err := s.db.Exec(ctx, string(b)); err != nil {
			return err
		}
	}

	return nil
}
