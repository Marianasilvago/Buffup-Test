package postgres

import (
	"context"

	"github.com/buffup/backend-challenge/internal/entities"
	"github.com/google/uuid"
)

//CreateLeaderboard implements create leaderboard database responsibility
//TODO: if not already available then save the leaderboard entityid and create a view which will be
//updated whenever someone is awarded points for provided entityid
func (s *Store) CreateLeaderboard(ctx context.Context, gameIDs []uuid.UUID) (uuid.UUID, error) {
	return uuid.UUID{}, nil
}

//GetLeaderboard implements fetch leaderboard database responsibility
//TODO: fetch the leaderboard from leaderboard & views(updated based on gameid ref) table
func (s *Store) GetLeaderboard(ctx context.Context, leaderboardID uuid.UUID) ([]entities.LeaderBoardResponse, error) {
	return nil, nil
}
