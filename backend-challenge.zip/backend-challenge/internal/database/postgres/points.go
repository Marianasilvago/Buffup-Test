package postgres

import (
	"context"

	"github.com/buffup/backend-challenge/internal/entities"
	"github.com/google/uuid"
)

//AwardPoints implements award points database responsibility
//TODO: save the awrded points with entityid and update views if exists for that entityid
func (s *Store) AwardPoints(ctx context.Context, point entities.Point) (uuid.UUID, error) {
	return uuid.UUID{}, nil
}
