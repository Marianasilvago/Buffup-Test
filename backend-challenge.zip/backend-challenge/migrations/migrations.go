package migrations

import "embed"

//go:embed migrate
var FS_Migrate embed.FS

//go:embed seed
var FS_Seed embed.FS
