-- dummy records for testing
SET
  @name := 'Stefan';

INSERT INTO
  entities (
    name
  )
VALUES
  (
    @name
  );

-- dummy records for testing
SET
  @name := 'Ross K';

INSERT INTO
  entities (
    name
  )
VALUES
  (
    @name
  );

-- dummy records for testing
SET
  @name := 'Kate Middleton';

INSERT INTO
  entities (
    name
  )
VALUES
  (
    @name
  );