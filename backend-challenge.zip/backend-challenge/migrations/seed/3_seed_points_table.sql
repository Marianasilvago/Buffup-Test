-- dummy records for testing
SET
  @game_id := SELECT id from games where name='WC2021',
  @entity_id := SELECT id from entities where name='Ross K',
  @count := 20;

INSERT INTO
  points (
    game_id,
    entity_id,
    count
  )
VALUES
  (
    @game_id,
    @entity_id,
    @count
  );

SET
  @game_id := SELECT id from games where name='WC2021',
  @entity_id := SELECT id from entities where name='Stefan',
  @count := 10;

INSERT INTO
  points (
    game_id,
    entity_id,
    count
  )
VALUES
  (
    @game_id,
    @entity_id,
    @count
  );

SET
  @game_id := SELECT id from games where name='WC2021',
  @entity_id := SELECT id from entities where name='Stefan',
  @count := 30;

INSERT INTO
  points (
    game_id,
    entity_id,
    count
  )
VALUES
  (
    @game_id,
    @entity_id,
    @count
  );

SET
  @game_id := SELECT id from games where name='T20-WC',
  @entity_id := SELECT id from entities where name='Ross K',
  @count := 20;

INSERT INTO
  points (
    game_id,
    entity_id,
    count
  )
VALUES
  (
    @game_id,
    @entity_id,
    @count
  );

SET
  @game_id := SELECT id from games where name='T20-WC',
  @entity_id := SELECT id from entities where name='Kate Middleton',
  @count := 21;

INSERT INTO
  points (
    game_id,
    entity_id,
    count
  )
VALUES
  (
    @game_id,
    @entity_id,
    @count
  );