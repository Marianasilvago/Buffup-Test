-- dummy records for testing
SET
  @name := 'WC2021',
  @description := 'Cricket World Cup 2021';

INSERT INTO
  games (
    name,
    description
  )
VALUES
  (
    @name,
    @description
  );

-- dummy records for testing
SET
  @name := 'T20-WC',
  @description := 'Cricket T20 World Cup 2020';

INSERT INTO
  games (
    name,
    description
  )
VALUES
  (
    @name,
    @description
  );

-- dummy records for testing
SET
  @name := 'EPL-2021',
  @description := 'English Premier League 2021';

INSERT INTO
  games (
    name,
    description
  )
VALUES
  (
    @name,
    @description
  );