CREATE TABLE IF NOT EXISTS games (
	id UUID NOT NULL DEFAULT uuid_generate_v1() , 
    name VARCHAR(25) NOT NULL,
    description TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT NOW() COMMENT "the date and time of creation",
	CONSTRAINT id_games PRIMARY KEY ( id )
);