CREATE TABLE IF NOT EXISTS entities (
	id UUID NOT NULL DEFAULT uuid_generate_v1() , 
    name VARCHAR(30) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW() COMMENT "the date and time of creation",
	CONSTRAINT id_entities PRIMARY KEY ( id )
);