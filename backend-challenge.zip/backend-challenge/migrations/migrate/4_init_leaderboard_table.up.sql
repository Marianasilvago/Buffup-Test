CREATE TABLE IF NOT EXISTS leaderboard (
	id UUID NOT NULL DEFAULT uuid_generate_v1() , 
    game_id UUID[] NOT NULL,
    description TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT NOW() COMMENT "the date and time of creation",
	CONSTRAINT id_leaderboard PRIMARY KEY ( id ),
    CONSTRAINT fk_game FOREIGN KEY(game_id) REFERENCES games(id) ON DELETE CASCADE,
);