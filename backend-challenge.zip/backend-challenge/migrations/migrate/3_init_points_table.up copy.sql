CREATE TABLE IF NOT EXISTS points (
	id UUID NOT NULL DEFAULT uuid_generate_v1() , 
    entity_id UUID NOT NULL,
    game_id UUID NOT NULL,
    count uint,
    created_at TIMESTAMP NOT NULL DEFAULT NOW() COMMENT "the date and time of creation",
	CONSTRAINT id_points PRIMARY KEY ( id ),
    CONSTRAINT fk_entity FOREIGN KEY(entity_id) REFERENCES entities(id) ON DELETE CASCADE,
    CONSTRAINT fk_game FOREIGN KEY(game_id) REFERENCES games(id) ON DELETE CASCADE,
);