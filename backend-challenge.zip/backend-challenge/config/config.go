package config

import (
	"embed"
)

//go:embed configs
var embedFS embed.FS

// AppConfig maps the environment variables into a struct.
type EnvConfig struct {
	// AppEnv is the application environment that determines `configs/<APP_ENV>.env` to load.
	AppEnv string `env:"APP_ENV" envDefault:"development"`

	// GRPCAddress is the GRPC server's address.
	GRPCAddress string `env:"GRPC_ADDRESS,notEmpty"`

	// PrimaryDBUri is the primary database URI.
	PrimaryDBUri string `env:"PRIMARY_DB_URI,notEmpty"`

	// PrimaryReplicaDBUri is the primary replica database URI.
	PrimaryReplicaDBUri string `env:"PRIMARY_REPLICA_DB_URI"`

	// ServiceName is the application's service name.
	ServiceName string `env:"SERVICE_NAME" envDefault:"svc-points"`

	// TracerCollectorAddress is the OpenTelemetry trace collector address.
	TracerCollectorAddress string `env:"TRACER_COLLECTOR_ADDRESS,notEmpty"`
}

// NewConfig loads/decrypts the 'configs/<APP_ENV>.env' file into EnvConfig struct.
func NewConfig() (EnvConfig, error) {
	config := EnvConfig{}
	err := ParseEnvConfig(&config, embedFS)

	return config, err
}
