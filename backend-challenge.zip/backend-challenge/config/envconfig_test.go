package config

import (
	"embed"
	"net/http"
	"os"
	"testing"

	"github.com/stretchr/testify/assert"
)

//go:embed testdata
var embedFS_test embed.FS

func TestParseEnvConfig(t *testing.T) {
	{
		config := struct {
			SameSite http.SameSite `env:"SAME_SITE"`
		}{}

		os.Setenv("APP_ENV", "development")
		os.Setenv("SAME_SITE", "test")
		oldConfigsDir := ConfigsDir
		ConfigsDir = "testdata/configs"
		defer func() {
			os.Unsetenv("APP_ENV")
			os.Unsetenv("SAME_SITE")
			ConfigsDir = oldConfigsDir
		}()

		err := ParseEnvConfig(&config, embedFS_test)
		assert.EqualError(t, err, "env: parse error on field \"SameSite\" of type \"http.SameSite\": strconv.Atoi: parsing \"test\": invalid syntax")
	}

	{
		config := struct {
			ApiKey string `env:"API_KEY,required"`
		}{}

		os.Setenv("APP_ENV", "development")
		defer func() {
			os.Unsetenv("APP_ENV")
		}()

		err := ParseEnvConfig(&config, embedFS_test)
		assert.EqualError(t, err, "env: required environment variable \"API_KEY\" is not set")
	}

	{
		config := struct {
			ApiKey string `env:"API_KEY,notEmpty"`
		}{}

		os.Setenv("APP_ENV", "development")
		os.Setenv("API_KEY", "")
		defer func() {
			os.Unsetenv("APP_ENV")
			os.Unsetenv("API_KEY")
		}()

		err := ParseEnvConfig(&config, embedFS_test)
		assert.EqualError(t, err, "env: environment variable \"API_KEY\" should not be empty")
	}

	{
		config := struct {
			SameSite   http.SameSite `env:"SAME_SITE"`
			SecretKey  []byte        `env:"SECRET_KEY,unset"`
			SecretKeys [][]byte      `env:"SECRET_KEYS"`
		}{}

		os.Setenv("APP_ENV", "development")
		os.Setenv("SAME_SITE", "2")
		os.Setenv("SECRET_KEY", "xxx")
		os.Setenv("SECRET_KEYS", "xxx,yyy")
		oldConfigsDir := ConfigsDir
		ConfigsDir = "testdata/configs"
		defer func() {
			os.Unsetenv("APP_ENV")
			os.Unsetenv("SAME_SITE")
			os.Unsetenv("SECRET_KEY")
			os.Unsetenv("SECRET_KEYS")
			ConfigsDir = oldConfigsDir
		}()

		err := ParseEnvConfig(&config, embedFS_test)
		assert.Nil(t, err)
		assert.Equal(t, config.SameSite, http.SameSiteLaxMode)
		assert.Equal(t, config.SecretKey, []byte("xxx"))
		assert.Equal(t, config.SecretKeys, [][]byte{[]byte("xxx"), []byte("yyy")})

		_, exists := os.LookupEnv("SECRET_KEY")
		assert.Equal(t, exists, false)
	}
}
