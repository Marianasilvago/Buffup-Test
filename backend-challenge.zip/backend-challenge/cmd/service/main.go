package main

import (
	"context"
	"log"
	"os"
	"os/signal"
	"runtime"
	"syscall"

	"github.com/buffup/backend-challenge/api"
	"github.com/buffup/backend-challenge/config"
	"github.com/buffup/backend-challenge/internal/app"
	"github.com/buffup/backend-challenge/internal/database"
	"github.com/buffup/backend-challenge/internal/database/postgres"
	sdkgrpc "github.com/buffup/backend-challenge/internal/grpc"
	"github.com/buffup/backend-challenge/internal/implementations"
	"github.com/buffup/backend-challenge/internal/o11y"
	"github.com/buffup/backend-challenge/internal/support"

	"google.golang.org/grpc"
)

func init() {
	if os.Getenv("APP_ENV") == "" {
		if err := os.Setenv("APP_ENV", "development"); err != nil {
			panic(err)
		}
	}
}

func main() {
	//dsn := "postgres://postgres:postgres@localhost:55021/points?sslmode=disable"

	var (
		err                           error
		tracerProvider                *o11y.TracerProvider
		tracerProviderShutdownHandler func() error
	)

	// Setup the app's config.
	app.Config, err = config.NewConfig()
	if err != nil {
		log.Fatalln(err)
	}

	// Setup the app's tracer.
	app.Tracer, tracerProvider, tracerProviderShutdownHandler, err = app.NewTracer(app.Config)
	if err != nil {
		log.Fatalln(err)
	}

	// Setup the app's logger.
	app.Logger = support.NewLogger()

	// Setup the app's databases.
	database, err := postgres.NewStore(context.Background(), app.Config.PrimaryDBUri, app.Logger)
	if err != nil {
		log.Fatalln(err)
	}

	//Setup the app's database schema
	err = database.Migrate(context.Background())
	if err != nil {
		log.Fatalln(err)
	}

	//Setup the app's seed data
	err = database.Seed(context.Background())
	if err != nil {
		log.Fatalln(err)
	}

	// Setup the app's gRPC/HTTP server.
	app.Server, err = app.NewServer(
		app.Config,
		app.Logger,
		tracerProvider,
		tracerProviderShutdownHandler,
		func() error {
			return nil
		},
		[]grpc.UnaryServerInterceptor{},
	)
	if err != nil {
		log.Fatalln(err)
	}

	// Register the gRPC server implementation.
	api.RegisterPointServiceServer(
		app.Server.GRPCServer(),
		implementations.NewServer(database),
	)

	//Finally serve the application
	serve(app.Logger, app.Server, database)
}

func serve(logger *support.Logger, server *sdkgrpc.Server, db database.Store) {
	httpDone := make(chan bool, 1)
	httpQuit := make(chan os.Signal, 1)
	signal.Notify(httpQuit, os.Interrupt)
	signal.Notify(httpQuit, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		<-httpQuit

		logger.Infof("* Gracefully shutting down the %s server...", server.Type())
		if err := server.GracefulStop(); err != nil {
			logger.Error(err)
		}

		if err := server.GracefulShutdownHandler(); err != nil {
			logger.Error(err)
		}

		if err := server.TracerProviderShutdownHandler(); err != nil {
			logger.Error(err)
		}

		err := db.Close()
		if err != nil {
			logger.Error(err)
		}

		defer func() {
			_ = logger.Sync()
		}()

		close(httpDone)
	}()

	logger.Infof("* Go Version: %s", runtime.Version())

	logger.Infof("* The %s server is listening on %s...", server.Type(), server.Addr())

	if server.PostRunCallback() != nil {
		if err := server.PostRunCallback()(); err != nil {
			logger.Fatal(err)
		}
	}

	if err := server.Serve(); err != nil {
		logger.Fatal(err)
	}

	<-httpDone
}
